<?php

namespace WP2StaticZip;

use Exception;

class WP2StaticZipException extends Exception {
}

